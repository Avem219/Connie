@echo off
if not "%~1"=="min" (
    start /min "" cmd /c "%~f0" min
    exit /b
)
setlocal EnableDelayedExpansion
set "OUT=%~dp0Networkchuck.txt"
(
    echo ==========================================
    echo       NETWORKCHUCK WIFI REPORT
    echo ==========================================
    echo.
    echo Computer: %COMPUTERNAME%
    echo Date: %DATE% %TIME%
    echo.
    for /f "tokens=2 delims=:" %%A in ('netsh wlan show profiles ^| findstr /i "All User Profile"') do (
        set "SSID=%%A"
        set "SSID=!SSID:~1!"
        echo ------------------------------------------
        echo Network: !SSID!
        echo ------------------------------------------
        netsh wlan show profile name="!SSID!" key=clear
        echo.
    )
) > "%OUT%"
exit /b
